#include "Robot.h"

/*
	BASE STATUS
Alpha:
	atk = 150
	def = 50
	hp = 100
Beta:
	atk = 50
	def = 150
	hp = 150
Gamma:
	atk = 100
	def = 100
	hp = 100
*/

void main()
{
	Combine b;

	b.getRobotInfo();

	b.clearMem();
}